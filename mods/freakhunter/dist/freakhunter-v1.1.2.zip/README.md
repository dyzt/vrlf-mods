# FREAKHUNTER VRLF Mod

Absolute light gun aim for FREAKHUNTER. The game aims its reticle by mouse movement; this BepInEx mod puts the reticle on the mouse cursor, so it works with any light gun that moves the cursor: VRLF (VR Lightgun Framework, with its FREAKHUNTER profile), Sinden, GunCon and others, or a plain mouse. Fullscreen and windowed both work.

## Install
1. In Steam, right-click FREAKHUNTER > Manage > Browse local files.
2. Extract this zip into that folder, so `winhttp.dll` sits beside `FREAKHUNTER.exe`.
3. Launch the game. `BepInEx/LogOutput.log` should contain "FREAKHUNTER VRLF Mod active".

VRLF players can install it from the VRLF Mods manager instead.

Steam Deck / Linux (Proton): add the launch option `WINEDLLOVERRIDES="winhttp=n,b" %command%`.

## Settings
`BepInEx/config/com.vrlightgun.freakhunter.cfg`:
- `AbsoluteAim` (true): the reticle follows the cursor. Recoil and auto-aim no longer move it. False = the game's own mouse aim.
- `HideReticle` (false): hide the game's reticle.
- `LogAim` (false): log the cursor and reticle to `BepInEx/LogOutput.log`.

## Sinden
- Use the Sinden software's mouse mode: trigger = left click (fire).
- Map the gun's buttons to the game's keys: W/S move, A/D turn, Q/E strafe, 1-4 interact, right click Use Item, Tab map, Escape pause.
- The game draws no border; add one with ReShade or a border app.

## Uninstall
Delete `winhttp.dll`, `doorstop_config.ini`, `.doorstop_version` and the `BepInEx` folder.

Bundled: BepInEx 5.4.23 (MIT/LGPL) with Unity Doorstop, HarmonyX, MonoMod and Mono.Cecil, unmodified. FREAKHUNTER is by goop lord; this is an unofficial fan mod that changes no game files.
