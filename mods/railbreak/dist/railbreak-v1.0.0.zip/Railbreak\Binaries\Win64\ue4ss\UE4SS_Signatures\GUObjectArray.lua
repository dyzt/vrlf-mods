-- Railbreak (UE 5.3, 2024-04-10 build): UE4SS's stock GUObjectArray scan finds nothing.
-- Match: UObjectBaseInit's inlined AllocateObjectPool tail,
--   mov edx,[rip+MaxObjectsNotConsideredByGC]; test edx,edx; jle; lea rcx,[rip+ObjObjects]; call; call; call; mov byte [rip+x],1
-- ObjObjects sits at GUObjectArray+0x10.
function Register()
    return "8B 15 ?? ?? ?? ?? 85 D2 7E ?? 48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? E8 ?? ?? ?? ?? E8 ?? ?? ?? ?? C6 05 ?? ?? ?? ?? 01"
end

function OnMatchFound(MatchAddress)
    local NextInstr = MatchAddress + 0x11
    local AccessOffset = DerefToInt32(MatchAddress + 0x0D)
    return NextInstr + AccessOffset - 0x10
end
