-- RailbreakVrlf: drives Railbreak's P2 crosshair widget from the VRLF aim bus.
-- UE4SS glue only; the logic is vrlf_core.lua. Anything missing leaves the game stock.
local core = require("vrlf_core")

local TAG = "[RailbreakVrlf] "
local SEAMS = {
    pc = "/Game/MP_System_V3/Game/Blueprints/Core/PC_MPS.PC_MPS_C:ReceiveTick",
}
local GATE_IN_MENU = true     -- spike: no reticles show in menus
local MENU_PROPERTY = "IsInMenu?"
local LIVENESS_S = 0.5
local BUS_RETRY_S = 2.0
local SPIKE_EVERY = 6         -- ~10 Hz at 60 fps

local function log(msg) print(TAG .. msg .. "\n") end
local function valid(obj) return obj ~= nil and obj:IsValid() end

local mod_dir = core.mod_dir(debug.getinfo(1, "S").source)
local cfg_text = nil
if mod_dir then
    local f = io.open(mod_dir .. "\\railbreak_vrlf.cfg", "rb")
    if f then cfg_text = f:read("a") f:close() end
end
local cfg = core.parse_cfg(cfg_text)
local bus_path = core.bus_path()
log(("loaded; cfg %s; DriveP2=%s BusLane=%d AimScale=(%.3f,%.3f) AimOffset=(%.3f,%.3f) AimSpike=%s VerboseLog=%s; bus %s"):format(
    cfg_text and "read" or "missing (defaults)", tostring(cfg.DriveP2), cfg.BusLane,
    cfg.AimScaleX, cfg.AimScaleY, cfg.AimOffsetX, cfg.AimOffsetY,
    tostring(cfg.AimSpike), tostring(cfg.VerboseLog), tostring(bus_path)))

local reader = core.new_bus_reader(bus_path, BUS_RETRY_S)
local live = core.new_liveness(LIVENESS_S)
local layout_lib = nil
local clock = 0.0
local ticks = 0
local driver = nil        -- address of the PC_MPS whose ticks drive us
local calls_since_driver = 0  -- hook calls since the driver PC last ticked
local RELATCH_CALLS = 10      -- a level load replaces PC_MPS; take over once the old one stops
local last_state, last_live = nil, nil
local last_error = 0

local function verbose(msg) if cfg.VerboseLog then log(msg) end end

local function layout()
    if not valid(layout_lib) then layout_lib = StaticFindObject("/Script/UMG.Default__WidgetLayoutLibrary") end
    return valid(layout_lib) and layout_lib or nil
end

local function read_menu(pc)
    local ok, value = pcall(function() return pc[MENU_PROPERTY] end)
    return ok and value == true
end

local function on_tick(pc, dt)
    local addr = pc:GetAddress()
    if addr == driver then
        calls_since_driver = 0
    else
        calls_since_driver = calls_since_driver + 1
    end
    local hud = pc.W_HUD
    if not valid(hud) then
        if driver == addr then driver = nil verbose("driver PC lost its HUD") end
        return
    end
    if driver ~= addr and (driver == nil or calls_since_driver >= RELATCH_CALLS) then
        driver = addr
        calls_since_driver = 0
        verbose(("driver PC %X"):format(addr))
    end
    if driver ~= addr then return end
    clock = clock + dt
    ticks = ticks + 1

    local u, v, _, seq = reader:read_lane(cfg.BusLane, clock)
    if reader.state ~= last_state then
        verbose("bus " .. reader.state)
        last_state = reader.state
    end
    local is_live = false
    if u == nil then live:reset() else is_live = live:update(seq, clock) end
    if is_live ~= last_live then
        verbose(is_live and "lane live" or "lane stale")
        last_live = is_live
    end

    local cross = hud.CrosshairRailbreakP2
    if not valid(cross) then return end
    local lib = layout()
    if not lib then return end
    local size = lib:GetViewportSize(pc)
    local scale = lib:GetViewportScale(pc)
    if not scale or scale <= 0 then return end
    local w, h = size.X / scale, size.Y / scale
    local in_menu = read_menu(pc)

    if cfg.AimSpike then
        if ticks % SPIKE_EVERY == 0 then
            local t = cross.RenderTransform.Translation
            log(("spike uv=(%s,%s) seq=%s live=%s trans=(%.1f,%.1f) W=%.1f H=%.1f menu=%s dt=%.4f"):format(
                tostring(u), tostring(v), tostring(seq), tostring(is_live), t.X, t.Y, w, h, tostring(in_menu), dt))
        end
        return
    end
    if not cfg.DriveP2 or not is_live then return end
    if GATE_IN_MENU and in_menu then return end
    local tx, ty = core.map_aim(u, v, w, h, cfg)
    cross:SetRenderTranslation({ X = tx, Y = ty })
end

local function guarded(pc, dt)
    local ok, err = pcall(on_tick, pc, dt)
    if not ok and os.time() - last_error >= 5 then
        last_error = os.time()
        log("tick error: " .. tostring(err))
    end
end

local function register()
    return pcall(RegisterHook, SEAMS.pc, function(self, delta)
        guarded(self:get(), delta:get())
    end)
end

local hooked = false
local attempts = 0
LoopAsync(1000, function()
    attempts = attempts + 1
    ExecuteInGameThread(function()
        if hooked then return end
        hooked = register()
        if hooked then log("hooked " .. SEAMS.pc) end
    end)
    if attempts == 120 and not hooked then log("still waiting for " .. SEAMS.pc) end
    return hooked
end)
