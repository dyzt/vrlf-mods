-- Railbreak (UE 5.3, 2024-04-10 build): UE4SS's stock scan finds two candidates.
-- Match: IConsoleManager::SetupSingleton,
--   sub rsp,38h; cmp qword [rip+Singleton],0; jne; mov ecx,110h (sizeof FConsoleManager)
function Register()
    return "48 83 EC 38 48 83 3D ?? ?? ?? ?? 00 0F 85 ?? ?? ?? ?? B9 10 01 00 00"
end

function OnMatchFound(MatchAddress)
    local NextInstr = MatchAddress + 0x0C
    local AccessOffset = DerefToInt32(MatchAddress + 0x07)
    return NextInstr + AccessOffset
end
