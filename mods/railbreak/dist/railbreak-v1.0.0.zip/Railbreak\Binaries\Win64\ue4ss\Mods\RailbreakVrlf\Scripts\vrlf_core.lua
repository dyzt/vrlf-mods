-- Pure logic for the RailbreakVrlf UE4SS mod: cfg, bus decoding, liveness, mapping.
-- No Unreal API here, so tests/test_core.lua runs it under stock Lua 5.4.
local M = {}

M.DEFAULTS = {
    DriveP2 = true,
    BusLane = 0,
    AimScaleX = 1.0,
    AimScaleY = 1.0,
    AimOffsetX = 0.0,
    AimOffsetY = 0.0,
    AimSpike = false,
    VerboseLog = false,
}

local KINDS = {
    DriveP2 = "bool", BusLane = "lane",
    AimScaleX = "num", AimScaleY = "num", AimOffsetX = "num", AimOffsetY = "num",
    AimSpike = "bool", VerboseLog = "bool",
}
local BOOLS = {
    ["true"] = true, ["1"] = true, on = true, yes = true,
    ["false"] = false, ["0"] = false, off = false, no = false,
}

M.HEADER_BYTES = 16
M.LANE_BYTES = 16
M.MAX_LANES = 4

-- Key=Value lines, # comments stripped first (a bool compares the whole remainder,
-- so an unstripped comment silently reads false), unknown keys ignored, invalid
-- values keep the default.
function M.parse_cfg(text)
    local cfg = {}
    for k, v in pairs(M.DEFAULTS) do cfg[k] = v end
    if type(text) ~= "string" then return cfg end
    for line in text:gmatch("[^\r\n]+") do
        local stripped = line:gsub("#.*$", "")
        local key, value = stripped:match("^%s*([%w_]+)%s*=%s*(.-)%s*$")
        local kind = key and KINDS[key]
        if kind == "bool" then
            local b = BOOLS[value:lower()]
            if b ~= nil then cfg[key] = b end
        elseif kind == "num" then
            local n = tonumber(value)
            if n and n == n and n ~= math.huge and n ~= -math.huge then cfg[key] = n end
        elseif kind == "lane" then
            local n = tonumber(value)
            if n and n == math.floor(n) and n >= 0 and n < M.MAX_LANES then cfg[key] = math.tointeger(n) end
        end
    end
    return cfg
end

function M.lane_offset(lane)
    return M.HEADER_BYTES + lane * M.LANE_BYTES
end

function M.header_ok(bytes)
    if type(bytes) ~= "string" or #bytes < 8 or bytes:sub(1, 4) ~= "VRLF" then return false end
    return (string.unpack("<I4", bytes, 5)) == 1
end

function M.decode_lane(bytes)
    if type(bytes) ~= "string" or #bytes < M.LANE_BYTES then return nil end
    local u, v, buttons, seq = string.unpack("<ffI4I4", bytes)
    return u, v, buttons, seq
end

-- seq is a changed/unchanged signal only. First sight of a nonzero seq proves
-- nothing (VRLF may have exited long ago), so life starts at the first change.
local Liveness = {}
Liveness.__index = Liveness

function M.new_liveness(timeout_s)
    return setmetatable({ timeout = timeout_s, last_seq = nil, changed_at = nil }, Liveness)
end

function Liveness:update(seq, now)
    if self.last_seq == nil then
        self.last_seq = seq
        return false
    end
    if seq ~= self.last_seq then
        self.last_seq = seq
        self.changed_at = now
    end
    if seq == 0 or self.changed_at == nil then return false end
    return now - self.changed_at <= self.timeout
end

function Liveness:reset()
    self.last_seq = nil
    self.changed_at = nil
end

local function clamp(x, lo, hi)
    if x < lo then return lo end
    if x > hi then return hi end
    return x
end

-- Bus UV (0..1, top-left origin) to widget RenderTranslation about screen centre.
function M.map_aim(u, v, w, h, cfg)
    local tx = ((u - 0.5) * cfg.AimScaleX + cfg.AimOffsetX) * w
    local ty = ((v - 0.5) * cfg.AimScaleY + cfg.AimOffsetY) * h
    return clamp(tx, -w / 2, w / 2), clamp(ty, -h / 2, h / 2)
end

-- Same directory GetTempPathW gives VRLF: TMP, then TEMP, then USERPROFILE.
function M.bus_path(getenv)
    getenv = getenv or os.getenv
    for _, name in ipairs({ "TMP", "TEMP", "USERPROFILE" }) do
        local dir = getenv(name)
        if dir and dir ~= "" then
            return (dir:gsub("[\\/]+$", "")) .. "\\VRLF_AimBus.bin"
        end
    end
    return nil
end

-- "@...\RailbreakVrlf\Scripts\main.lua" -> "...\RailbreakVrlf"
function M.mod_dir(source)
    if type(source) ~= "string" then return nil end
    local path = source:gsub("^@", "")
    return path:match("^(.*)[\\/]Scripts[\\/][^\\/]+$")
end

local Reader = {}
Reader.__index = Reader

function M.new_bus_reader(path, retry_s, open_fn)
    return setmetatable({
        path = path, retry = retry_s, open = open_fn or io.open,
        file = nil, next_try = -math.huge, state = "closed",
    }, Reader)
end

function Reader:_fail(state, now)
    if self.file then self.file:close() end
    self.file = nil
    self.state = state
    self.next_try = now + self.retry
    return nil
end

function Reader:read_lane(lane, now)
    if not self.file then
        if now < self.next_try then return nil end
        local f = self.path and self.open(self.path, "rb")
        if not f then return self:_fail("missing", now) end
        f:setvbuf("no")
        self.file = f
    end
    self.file:seek("set", 0)
    if not M.header_ok(self.file:read(M.HEADER_BYTES)) then return self:_fail("bad_header", now) end
    self.file:seek("set", M.lane_offset(lane))
    local u, v, buttons, seq = M.decode_lane(self.file:read(M.LANE_BYTES))
    if not u then return self:_fail("short", now) end
    self.state = "open"
    return u, v, buttons, seq
end

return M
