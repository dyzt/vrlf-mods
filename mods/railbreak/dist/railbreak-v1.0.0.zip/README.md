# Railbreak VRLF Mod

Player 2 aims 1:1 with a second VR gun in VR Lightgun Framework (VRLF). Player 1 needs no mod.

Requires VRLF 0.1.37 or newer (it writes the aim bus file this mod reads).

## Install
Extract this zip into the Railbreak game folder (the one with `Railbreak.exe`), or install it from vrlf-mods.

## Use
In VRLF pick the "Railbreak" profile. In Railbreak's main menu, click "1 player" so it reads "2 player".
P2's gun drives the red P2 crosshair.
Settings: `Railbreak\Binaries\Win64\ue4ss\Mods\RailbreakVrlf\railbreak_vrlf.cfg`.

## Uninstall
Delete `Railbreak\Binaries\Win64\dwmapi.dll` and the `ue4ss` folder beside it.

## Notes
- Windows user names with characters outside your system code page can stop the mod finding VRLF's aim file.
- Playing alone? Leave Railbreak on "1 player"; the P2 gun in VRLF can stay on its rack.

Includes UE4SS (MIT, `ue4ss\LICENSE`). Installing this zip replaces an existing UE4SS
(`UE4SS.dll`, `ue4ss\Mods\mods.txt`, `ue4ss\Mods\mods.json`). Already using UE4SS for other
mods? Instead copy `ue4ss\Mods\RailbreakVrlf` and the two files in `ue4ss\UE4SS_Signatures`
(UE4SS cannot attach to this game build without them), then enable `RailbreakVrlf` in your own
`ue4ss\Mods\mods.txt` (`RailbreakVrlf : 1`) and `mods.json`.
