# Blue Estate — VRLF co-op aim mod

A `dinput8.dll` proxy for **Blue Estate** (Steam appid 305380, Unreal Engine 3) that
gives **Player 2 in co-op** true absolute lightgun aim. P1 already works with a normal
VRLF `absolute_raw` mouse profile; P2 in co-op is otherwise gamepad-only and aims with a
velocity integrator, which no framework aim mode can make absolute. This mod hooks the
game's own per-player crosshair update and drives P2's crosshair from the
[VRLF aim bus](https://github.com/dyzt) (`Local\VRLF_AimBus`).

Companion to the [VR Lightgun Framework]. Part of the VRLF game-mod family
(HOTD1/HOTD2/Heavy Fire/Big Buck Hunter/Reload).

## How it works

- Loads in-process via a `dinput8.dll` proxy next to `BEGame.exe` (the game imports
  DINPUT8 directly; every export forwards to the real system DLL).
- Resolves `UBEPlayerInput::execUpdateCrossHairPosition` **by name** from UE3's native
  registration table in the module — no hardcoded addresses, ASLR-safe. A missing symbol
  leaves the game 100% stock.
- The hooked native hands us the `BEPlayerInput` instance (= the player). After the
  game's own update, the mod overwrites the pad player's crosshair coordinate with the
  bus target for that player. Stale/absent bus ⇒ stock input untouched.
- **Crosshair removal** is done by `tools/apply_nocrosshair.py` — a redistribution-
  clean rebuild of the long-standing community "no crosshair" patch. It decompresses
  the user's own `BEGame.upk` (pure-python LZO1X), applies a 29-byte patch that NOPs
  the crosshair display bytecode, and verifies the result byte-for-byte against the
  community patch (MD5). Keeps a `.vrlf-backup`; `--restore` (or Steam file
  verification) undoes it. The tool ships zero game content — only offsets, 29 bytes
  of replacement data, and hashes — so it is safe to distribute on GitHub / via the
  VRLF mod manager. Steam build only (base MD5 `FE76FB…`); anything else is refused.
- The DLL also has a dormant `RemoveCrosshair` cfg toggle (in-process GUI-channel
  suppression: `GetCrosshairPos` result spoof + visual/pixel coord parks, gameplay-
  gated so menu cursors survive). It kills the ring cursor in gameplay but NOT the
  per-weapon crosshair — that widget reads engine-pump-fresh mouse state that
  rewrites before any script hook runs, which is why the upk patch is the real fix.
  Left in place as measured infrastructure; default off. (Falsified seams — do not
  retry: `execDrawCrosshair` never fires; `AActor::SetHidden` on the weapon actor
  changes nothing visually; `SetHidden` on the pawn hides the view model but blinds
  the enemy AI. See `src/hud.h`.)
- For 1:1 lightgun aim also set `MouseSnap_P0/P1=0` and `PaddleSnap_P0/P1=0` in
  `Documents\My Games\BlueEstate\BEGame\Config\BEGame.ini` `[SavePCControllerConfig]`
  (disables aim-assist snap and its lock-on visuals).

The DLL never writes game memory except the crosshair floats described above; the
upk patcher is a separate, explicit, reversible step. Everything fails safe.

## Build

`build.bat` (MSVC) → `bin/win64/dinput8.dll` and `bin/win32/dinput8.dll`.
Drop the DLL matching the running exe (this machine: Win64) next to
`…\Blue Estate\Binaries\Win64\BEGame.exe`, alongside `blue_estate_vrlf.cfg`.

## Config (`blue_estate_vrlf.cfg`)

`Key=Value`, `#` comments, unknown keys ignored, every default fail-safe. See the file
for the full list. First-run defaults enable the observe-only **spike** (`AimSpike=true`)
which logs the data needed to fill in the member offsets; the drive stays inert until
those offsets are set. See `docs/superpowers/` for the design and the offset-discovery
procedure.

## Status

Complete and hardware-verified (2026-07-10): P2 joins with the pad stick and aims 1:1
from bus lane 0 in co-op (drive targets `m_iPlayerId == PaddlePlayerId`, not the lying
device enum). `RemoveCrosshair` verified solo on-screen: gameplay reticle gone, menu and
death-screen cursors intact; snap-"X" park pending an eyes-on-enemy check.

[VR Lightgun Framework]: https://github.com/dyzt
