# Credits

- **VR Lightgun Framework** — the VR intermediary this mod supports.
- Built on the standalone `dinput8.dll` proxy pattern proven by the Heavy Fire and
  Reload VRLF mods.
- The 2-player-lightgun problem in Blue Estate was first surfaced by the Sinden
  community (the dead "Mystery Wizard" 2-Sinden patch used the game's per-mouse
  device binding, which VRLF can't use). This mod takes a different route: it drives
  the game's own per-player crosshair state, so P2 need not be a distinct physical mouse.
- **MinHook** by Tsuda Kageyu and contributors (https://github.com/TsudaKageyu/minhook),
  BSD 2-Clause licensed — vendored under `third_party/minhook/` and used for the inline
  hook on `UBEPlayerInput::execUpdateCrossHairPosition`. See
  `third_party/minhook/LICENSE.txt` for its full license text.
- Unreal Engine 3 is a trademark of Epic Games; Blue Estate is © HeSaw / Focus Home
  Interactive. This mod ships no game code — only a hook that calls into the installed
  game — and patches nothing on disk.
