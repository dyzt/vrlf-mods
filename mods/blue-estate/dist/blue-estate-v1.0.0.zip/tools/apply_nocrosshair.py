#!/usr/bin/env python3
"""Blue Estate no-crosshair patch — VRLF redistribution-clean rebuild.

Removes the in-game crosshair rendering by patching the display code inside
BEGame.upk, reproducing the long-standing community "no crosshair" patch
byte-for-byte — WITHOUT distributing any game content. This tool ships only:
a pure-python LZO1X decompressor, 29 bytes of replacement data, and the MD5
hashes needed to verify every step. The game package itself always comes from
the user's own install.

What it does:
  1. Verifies the target BEGame.upk is the known Steam build
     (MD5 FE76FB4294DFB2617D724CE7DD94BE70).
  2. Decompresses the UE3 LZO-compressed package to the canonical
     uncompressed form (identical to what Gildor's decompress produces).
  3. Applies the 29-byte crosshair patch (NOPs the crosshair draw bytecode
     with EX_Nothing opcodes and zeroes an alpha constant).
  4. Verifies the result matches the community patch exactly
     (MD5 0A63FE0141F94B05186AF8613E6AB52A), keeps the original as
     BEGame.upk.vrlf-backup, and writes the patched file in place.

Usage:
  python apply_nocrosshair.py [path-to-BEGame.upk]   # patch (default: Steam path)
  python apply_nocrosshair.py --restore [path]       # put the backup back

Steam's "Verify integrity of game files" also restores the original.
"""
import hashlib
import os
import struct
import sys

STEAM_DEFAULT = r"H:\SteamLibrary\steamapps\common\Blue Estate\BEGame\COOKEDPCCONSOLE\BEGame.upk"
MD5_ORIGINAL = "FE76FB4294DFB2617D724CE7DD94BE70"   # Steam build, buildid 637056
MD5_PATCHED  = "0A63FE0141F94B05186AF8613E6AB52A"   # decompressed + crosshair patch
BACKUP_SUFFIX = ".vrlf-backup"

# The crosshair patch, in decompressed-package offsets. 29 bytes total: replaces
# the crosshair display bytecode with EX_Nothing (0x0b) no-ops / harmless variable
# reads, and zeroes a 255.0f alpha constant.
PATCH_RUNS = [
    (0x03766EC, bytes.fromhex("0000")),
    (0x037673C, bytes.fromhex("01552b00")),
    (0x0376741, bytes.fromhex("01552b000001552b00000b0b0b0b0b0b0b0b0b0b0b0b0b")),
]


def lzo1x_decompress(src, expected_len):
    """LZO1X decompress (pure python, decompress only)."""
    out = bytearray()
    ip = 0

    def copy_match(dist, cnt):
        pos = len(out) - dist
        if pos < 0:
            raise ValueError("bad LZO match distance")
        for _ in range(cnt):
            out.append(out[pos])
            pos += 1

    state = 0
    t = src[ip]
    if t > 17:
        ip += 1
        t -= 17
        out += src[ip:ip + t]
        ip += t
        state = 4 if t >= 4 else t
        t = src[ip]
        ip += 1
    else:
        t = src[ip]
        ip += 1

    while True:
        if t < 16:
            if state == 0:
                if t == 0:
                    while src[ip] == 0:
                        t += 255
                        ip += 1
                    t += 15 + src[ip]
                    ip += 1
                t += 3
                out += src[ip:ip + t]
                ip += t
                state = 4
                t = src[ip]
                ip += 1
                continue
            elif state == 4:
                dist = 1 + 0x800 + (t >> 2) + (src[ip] << 2)
                ip += 1
                copy_match(dist, 3)
                state = t & 3
            else:
                dist = 1 + (t >> 2) + (src[ip] << 2)
                ip += 1
                copy_match(dist, 2)
                state = t & 3
        elif t >= 64:
            dist = 1 + ((t >> 2) & 7) + (src[ip] << 3)
            ip += 1
            copy_match(dist, (t >> 5) + 1)
            state = t & 3
        elif t >= 32:
            cnt = t & 31
            if cnt == 0:
                while src[ip] == 0:
                    cnt += 255
                    ip += 1
                cnt += 31 + src[ip]
                ip += 1
            ds = src[ip] | (src[ip + 1] << 8)
            ip += 2
            copy_match(1 + (ds >> 2), cnt + 2)
            state = ds & 3
        else:
            base = (t & 8) << 11
            cnt = t & 7
            if cnt == 0:
                while src[ip] == 0:
                    cnt += 255
                    ip += 1
                cnt += 7 + src[ip]
                ip += 1
            ds = src[ip] | (src[ip + 1] << 8)
            ip += 2
            dist = base + (ds >> 2)
            if dist == 0:
                break   # EOF marker
            copy_match(dist + 0x4000, cnt + 2)
            state = ds & 3
        if state:
            out += src[ip:ip + state]
            ip += state
        t = src[ip]
        ip += 1

    if len(out) != expected_len:
        raise ValueError(f"LZO block decompressed to {len(out)}, expected {expected_len}")
    return bytes(out)


def decompress_package(orig):
    """UE3 compressed package -> canonical uncompressed image (Gildor-equivalent)."""
    nch = struct.unpack_from("<i", orig, 0x71)[0]
    chunks = [struct.unpack_from("<IIII", orig, 0x75 + 16 * i) for i in range(nch)]
    total = chunks[-1][0] + chunks[-1][1]
    img = bytearray(total)

    # Header: same summary minus the chunk table; later summary fields shift up.
    img[0:0x75] = orig[0:0x75]
    img[0x18] &= ~0x02                       # clear PKG_StoreCompressed
    struct.pack_into("<I", img, 0x6D, 0)     # CompressionFlags = 0
    struct.pack_into("<I", img, 0x71, 0)     # compressed chunk count = 0
    table_end = 0x75 + 16 * nch
    first_data = chunks[0][2]
    img[0x75:0x75 + (first_data - table_end)] = orig[table_end:first_data]

    for uo, us, co, cs in chunks:
        magic, blocksize, csz, usz = struct.unpack_from("<IIII", orig, co)
        if magic != 0x9E2A83C1 or usz != us:
            raise ValueError(f"bad chunk header at 0x{co:x}")
        nblocks = (usz + blocksize - 1) // blocksize
        pairs = [struct.unpack_from("<II", orig, co + 16 + 8 * i) for i in range(nblocks)]
        p = co + 16 + 8 * nblocks
        dec = bytearray()
        for cbs, ubs in pairs:
            blk = orig[p:p + cbs]
            p += cbs
            dec += blk if cbs == ubs else lzo1x_decompress(blk, ubs)
        img[uo:uo + us] = dec
    return img


def md5(data):
    return hashlib.md5(data).hexdigest().upper()


def main():
    args = [a for a in sys.argv[1:]]
    restore = "--restore" in args
    args = [a for a in args if a != "--restore"]
    path = args[0] if args else STEAM_DEFAULT
    backup = path + BACKUP_SUFFIX

    if restore:
        if not os.path.exists(backup):
            sys.exit(f"no backup found at {backup}")
        os.replace(backup, path)
        print(f"restored original: {path}")
        return

    if not os.path.exists(path):
        sys.exit(f"not found: {path}\nUsage: apply_nocrosshair.py [path-to-BEGame.upk]")

    data = open(path, "rb").read()
    h = md5(data)
    if h == MD5_PATCHED:
        print("already patched — nothing to do.")
        return
    if h != MD5_ORIGINAL:
        sys.exit(f"unexpected BEGame.upk (MD5 {h}).\n"
                 f"This tool only supports the Steam build (MD5 {MD5_ORIGINAL}).\n"
                 f"Use Steam's 'Verify integrity of game files' to restore the original first.")

    print("decompressing package (pure-python LZO, takes a few minutes)...")
    img = decompress_package(data)
    for off, repl in PATCH_RUNS:
        img[off:off + len(repl)] = repl

    out_hash = md5(img)
    if out_hash != MD5_PATCHED:
        sys.exit(f"patched output hash mismatch ({out_hash}) — aborting, nothing written.")

    if not os.path.exists(backup):
        os.replace(path, backup)
        print(f"original kept as {backup}")
    with open(path, "wb") as f:
        f.write(img)
    print(f"patched: {path}\ncrosshair rendering disabled (MD5 verified {MD5_PATCHED}).")


if __name__ == "__main__":
    main()
