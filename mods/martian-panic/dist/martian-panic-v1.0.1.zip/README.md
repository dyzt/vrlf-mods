# Martian Panic — VRLF Mod

A tiny [BepInEx 5](https://github.com/BepInEx/BepInEx) (Mono) plugin that hides the in-game
gameplay crosshair in **Martian Panic** (Steam app 2343850) so the game plays cleanly as a
VR lightgun title under the [VR Lightgun Framework](../VR%20Lightgun%20Framework). In VR your
aim *is* the pointer (the VR gun / laser), so the game's on-screen crosshair is redundant.

Martian Panic needs **no aim mod** — absolute mouse aim tracks 1:1 already (the game reads the
OS cursor via Rewired `Mouse.screenPosition` = `Input.mousePosition`, never locks it, and the
aim math has no deadzone). See the framework profile `profiles/martian_panic.json`
(`aim_mode: "absolute"`). This mod exists solely to remove the visual crosshair.

## What it does

One Harmony prefix on `Player.CheckCrosshairsDisplay()` — the only method that toggles the
crosshair. It forces the crosshair `Image` GameObject inactive and suppresses the game's
per-frame re-activation. Firing and hit-detection are untouched: they read a **separate**
`crosshairScreenPos` field, not the visual Image.

The patch is wrapped in a fail-safe try/catch — any error is logged and the game's own method
runs instead, so the mod can never take the game down (at worst the crosshair shows for a
frame). A crash-safe diagnostic (`BepInEx/plugins/MartianPanicVrlf.diag.log`) records the
first hide and any exception.

## Config — `BepInEx/plugins/MartianPanicVrlf.cfg`

| Key | Default | Meaning |
|-----|---------|---------|
| `HideCrosshair` | `true` | Hide the gameplay crosshair. Set `false` to restore stock behaviour. Hot-reloads live (~1 s). |
| `VerboseLog` | `false` | Extra one-line events to `BepInEx/LogOutput.log`. |

## Install

1. Install BepInEx 5 (x64, Mono) into the game root (`winhttp.dll`, `doorstop_config.ini`,
   `BepInEx/core/`). See [BUILD.md](BUILD.md).
2. Drop `MartianPanicVrlf.dll` into `BepInEx/plugins/`.
3. Launch once; confirm `BepInEx/LogOutput.log` shows `Martian Panic VRLF plugin loaded`.

## Build

See [BUILD.md](BUILD.md). `powershell -ExecutionPolicy Bypass -File build.ps1` compiles
`src/*.cs` with the .NET Framework `csc` (C# 5) and deploys to `BepInEx/plugins/`.

## Status

- Crosshair hide: **working** — verified flat on hardware 2026-07-10 (crosshair gone, aim +
  shooting unaffected).
- One non-reproducing crash on an early launch was investigated (see `docs/`); the patch was
  proven innocent by runtime diagnostics (clean `SetActive`, no exception). Left hardened with
  a fail-safe so any recurrence self-logs and cannot hard-crash the game.
- VR (through-framework) verification: pending.
