# Credits

## DemulShooter (argonlefou)

This mod's memory-patch offsets, stolen-byte counts, and cave/splice
technique for both Heavy Fire: Afghanistan and Heavy Fire: Shattered Spear
were transcribed, in most cases verbatim, from
[DemulShooter](https://github.com/djhardrix/DemulShooter) by **argonlefou**
and contributors — specifically the `Game_WndHeavyFire4Pc`-family handlers
covering:

- `SetHack_EnablePlayers_Steam` — the player on/off table splice used by
  `hfa::apply_takeover` / `hfss::apply_takeover`.
- `SetHack_Mouse_X` / `SetHack_Mouse_Y` — the absolute-aim reticle caves
  used by `hfa::apply_aim` / `hfss::apply_aim`.
- `SetHack_Mouse_Buttons` — the fire/reload/grenade button caves used by
  `hfa::apply_buttons` / `hfss::apply_buttons`.
- `Apply_NoCrosshairMemoryHack` — the crosshair-hide patch used by
  `hfa::apply_no_crosshair` / `hfss::apply_no_crosshair`.

DemulShooter's original research into these games' memory layout is what
makes this mod possible; without it, none of the offsets, byte sequences,
or player-table addresses used here would be known. This project exists
because DemulShooter's usual external-attach approach reliably crashes
these two games on Windows 11 (see `README.md`) — the fix implemented here
is to apply the *same* patches DemulShooter would, but from an in-process
proxy DLL instead of an external attacher, not to replace or compete with
DemulShooter's own reverse-engineering work.

## VR Lightgun Framework

This mod is a companion piece to the
[VR Lightgun Framework](https://github.com) project, which supplies the VR
aim capture/injection pipeline and the ViGEmBus virtual-pad plumbing this
mod's XInput input pump reads from.
