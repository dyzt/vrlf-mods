# Heavy Fire VRLF Mod

## What it is

A game-folder `dinput8.dll` proxy that makes Heavy Fire: Afghanistan and
Heavy Fire: Shattered Spear work as 1–4 player VR lightgun games with the
[VR Lightgun Framework](https://github.com), by patching the game's own
process memory in place — replicating the same instruction-splice hooks
[DemulShooter](https://github.com/djhardrix/DemulShooter) uses (player
on/off table, mouse-X/Y reticle floats, mouse-button reads, crosshair
alpha) — to fix the gamepad-takeover / "extra players" problem and inject
absolute 1:1 aim straight from each player's VR gun.

**Why this exists instead of just using DemulShooter directly:** on
Windows 11, DemulShooter's usual approach — an external process that
attaches to the already-running game and pokes its memory from the
outside — reliably crashes these two games. This mod applies the exact
same memory patches DemulShooter would, but *from inside* the game process
via a proxy DLL that Windows loads automatically at startup (before the
game's own code runs), which sidesteps whatever about external attach
triggers the Windows 11 crash. It loads via Windows DLL search order (the
game looks for `dinput8.dll` next to its `.exe` before falling back to the
system one); there is no external injector process to run, no separate
tool to keep open, and nothing to attach to the running game. To
uninstall, just delete `dinput8.dll` (and `heavyfire_vrlf.cfg` /
`heavyfire_vrlf.log` if you want a clean folder) from the game's install
directory — the game reverts to stock DirectInput8 behavior with no other
trace left behind.

See `BUILD.md` for build instructions and toolchain requirements, and
`CREDITS.md` for attribution to the DemulShooter project this mod's memory
offsets and patch bytes are transcribed from.

## Installation

1. Build `dinput8.dll` (see `BUILD.md`), or take a released build.
2. Copy `dinput8.dll` and `heavyfire_vrlf.cfg` into the game's install
   folder, next to the game `.exe` (e.g.
   `H:\SteamLibrary\steamapps\common\HeavyFireAfghanistan\`, or the
   Shattered Spear equivalent).
3. Copy the profile(s) from this repo's `profiles/` folder
   (`heavy_fire_afghanistan.json`, `heavy_fire_shattered_spear.json`) into
   `%APPDATA%\VRLightgunFramework\profiles\`, then select the matching
   profile in the VR Lightgun Framework before launching the game.
4. Edit `heavyfire_vrlf.cfg` as needed (see the config reference below, and
   the co-op notes for the runtime player-toggle keys).
5. Launch the game normally (e.g. via Steam, or the VR Lightgun Framework's
   shortcut launcher). `heavyfire_vrlf.log` is written next to wherever
   `dinput8.dll` loaded from, once the game starts.

## Configuration reference (`heavyfire_vrlf.cfg`)

All keys are `Key=Value` on their own line; unrecognized lines and lines
starting with `#` are ignored, so the shipped comments can stay in place.
Missing/unparsable keys fall back to their default.

| Key | Default | Meaning |
|---|---|---|
| `PlayerToggleKey2`..`PlayerToggleKey4` | `0x32`/`0x33`/`0x34` (`2`/`3`/`4`) | Win32 VK code (hex ok) that toggles that player on/off at runtime. P1 is always on. `0` disables a slot's toggle. Change only if the game itself reacts to those keys (e.g. use F-keys). |
| `PatchPlayerTable` | `true` | Applies the player on/off table cave — required for the runtime toggles to work (the game re-reads the on/off bytes each frame). Set `false` only to bisect a suspected takeover-stage crash. |
| `ShowCrosshair` | `false` | Defaults off, so the no-crosshair memory patch (see below) is applied and the game's own on-screen reticle is hidden — set `true` to keep it. VR aim is unaffected either way; this only controls the 2D overlay drawn on the captured window. |
| `HideGun` | `true` | Hides the first-person gun model by forcing the game's own `<2 players` "no gun, muzzle-flash only" draw path even in solo (verbatim of DemulShooter's `-nogun` patch). Set `false` to show the on-screen gun. |
| `ReverseCover` | `false` | Reverses the cover-lean direction (P1-only; see co-op notes). |
| `CoverSensitivity` | `3` | Tenths — `CoverSensitivity=3` → `cover_delta=0.3`. |
| `VerboseLog` | `false` | Enables chatty per-frame/optional log output. Lifecycle and error lines (unknown build, databank allocation failure, takeover applied) are logged **regardless** of this setting — see the MD5-gate note below. |
| `InvertY1`..`InvertY4` | `false` | Inverts the Y aim axis per player. |
| `AimScaleX1`..`AimScaleX4` | `1.0` | Horizontal aim scale multiplier per player. |
| `AimScaleY1`..`AimScaleY4` | `1.0` | Vertical aim scale multiplier per player. |

### `ShowCrosshair=false`

Applies DemulShooter's own no-crosshair memory hack (a static byte patch,
transcribed verbatim — no per-player databank involvement): the game's
reticle-alpha calculation is redirected to always compute an off-screen
result, so nothing is drawn, while the underlying aim/fire logic (and this
mod's VR aim injection) is completely unaffected. Useful if you'd rather
rely on the physical/virtual gun's own sight and find the game's 2D
reticle distracting on the captured screen in VR.

## Co-op / multiplayer notes

- **Players join/leave at runtime** — there is no fixed player count. P1 is
  always active; P2, P3 and P4 each toggle on or off when their
  `PlayerToggleKey` (default `2`/`3`/`4`) is pressed. The intended setup is a
  single co-op profile with up to four `"pad": true, "pad_aim": true` gun
  entries, each gun's `thumbstick_click` bound to its own number key — so a
  player joins or drops just by clicking their own stick. Each player still
  needs their own framework virtual ViGEmBus pad; a co-op profile repeats the
  single-player controller entry (see `profiles/heavy_fire_afghanistan.json`)
  once per player. Toggling takes effect whenever the game next re-reads its
  player table (a menu/continue/join screen); mid-level joins depend on the
  game, same as under DemulShooter.

- **XInput slot → player mapping assumption.** The mod reads player N's
  aim/buttons from XInput slot `N-1` (`XInputGetState(0)` → player 1,
  `XInputGetState(1)` → player 2, etc.), and the VR Lightgun Framework
  creates its virtual ViGEmBus pads in profile order — so **pad creation
  order = player order**, and the framework's first-created pad (typically
  the first `pad: true` gun listed in the profile) becomes Player 1,
  occupying XInput slot 0.

  **This assumes no other XInput devices are already occupying earlier
  slots.** If a real Xbox controller (or any other XInput-visible device)
  is connected when the game/framework starts, Windows may assign it an
  earlier slot than the framework's virtual pads, shifting every virtual
  pad's slot up by one and mis-assigning players (e.g. what should be
  Player 1's gun ends up driving Player 2 instead). **There is no config
  override for this in v1** — it is a documented limitation.
  **Recommendation: disconnect/power off any real Xbox controllers before
  launching**, so the framework's virtual pads claim slots 0..N-1 in the
  intended order.

- **Game-imposed co-op limits (not a mod bug — this is how the underlying
  game behaves, same as under DemulShooter).** Only Player 1 gets full
  control:
  - **Fire and reload** work for all players (1–4) via their own pad's
    buttons, routed through the per-player databank slots the mod's cave
    patches read. **Grenade** works for players 2–4; **Player 1's grenade
    may not fire via pad-X** (see the P1-grenade caveat below) — rebind it
    to the game's native keyboard grenade key for Player 1 if needed.
  - **Cover (A/S/D)** and **QTE prompts (W / Space)** are **Player-1-only**.
    The game hardcodes these to the keyboard, not to any per-player input
    table, so only Player 1's gun (via its thumbstick directions mapped to
    those keys in the profile) can lean into cover or respond to QTEs.
    Players 2–4 can fire/reload/grenade during gameplay but cannot
    trigger cover moves or clear QTEs themselves.

- **Known P1-grenade caveat.** The button cave's grenade branch is gated
  by `test ebx,ebx / je exit` (see `src/hacks_hfa.cpp`, `apply_buttons`),
  which **skips the grenade copy-out for player id 0 (Player 1)** —
  this mirrors DemulShooter's own default behavior for this game, not a
  regression introduced here. If Player 1's pad-X grenade button doesn't
  fire a grenade in testing, rebind grenade to the game's native keyboard
  grenade key for Player 1's profile entry instead of relying on
  `pad_button: x`.

## MD5 gate / Steam updates

The mod hashes the game's main module (MD5) at startup and only patches if
it recognizes the build (currently the Steam builds of both games). If
Valve/the publisher ships a game update, the exe's bytes — and therefore
its MD5 — change, and every offset this mod pokes could shift or
disappear underneath it. Rather than guess and risk corrupting the
process, the mod **fails safe**: it logs `unknown build <md5> - not
patching` and returns without touching game memory, and the game runs
completely stock (as if the DLL weren't there) instead of crashing.

**This lifecycle line is always written to `heavyfire_vrlf.log`, even with
`VerboseLog=false`** (as is the databank-allocation-failure line and the
"takeover applied" success line) — so after a Steam update silently stops
the mod from working, checking the log immediately tells you whether it's
an MD5 mismatch (game updated, table needs a new entry with the logged
MD5) or something else. You do not need to set `VerboseLog=true` just to
see whether patching is happening at all; that flag only gates additional
chatty/optional diagnostics.

## Antivirus false positives

This mod works by writing executable code into the running game's own
memory at runtime (the same class of technique DemulShooter, cheat
trainers, and some malware all use for different reasons). Some antivirus
products flag in-process memory patching heuristically regardless of
intent, and may quarantine `dinput8.dll` or block it from loading. If your
AV flags or removes the file, this is a false positive from the technique
itself, not an indication of anything malicious in this specific mod (which
is open source — see the source under `src/`) — add an exclusion for the
game's install folder, or for `dinput8.dll` specifically, if this happens.

## Deferred manual validation

The following requires a live 2–4 player run in VR and has not been
performed as part of this task:

1. With a co-op framework profile whose guns bind `thumbstick_click` to
   `2`/`3`/`4`, launch a game. Confirm the **runtime toggle**: pressing a
   player's key adds them (reticle tracks their own gun, they can
   fire/reload via their own pad) and pressing it again removes them, with
   the change reflected in `heavyfire_vrlf.log` (`player N toggled ON/OFF`).
   The player on/off table write in `mod.cpp` (P1) plus the pump's per-key
   toggles are the only mechanisms forcing/relaxing player slots — this step
   confirms they suffice with no separate "press start" popup patch.
2. Note **when** a toggle takes effect (which screen), since the game only
   re-reads its player table at certain points; if a mid-level join/leave
   stalls or is ignored, record the exact screen/prompt for follow-up (it
   would indicate the game needs an additional hook beyond the on/off table).
4. Confirm Player-1-only cover/QTE behavior above matches observed
   in-game behavior, and confirm/deny the P1-grenade caveat.
5. Set `ShowCrosshair=false` in `heavyfire_vrlf.cfg`, launch either game,
   and confirm the in-game reticle overlay vanishes while VR aim keeps
   working normally. Set it back to `true` and confirm the reticle
   reappears.
