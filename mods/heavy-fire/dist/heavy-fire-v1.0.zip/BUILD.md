# Build

This project produces a **32-bit** `dinput8.dll` proxy. Heavy Fire: Afghanistan /
Shattered Spear are 32-bit games, so the DLL, the compiler, and every dependency
must target x86 — a 64-bit `dinput8.dll` will simply fail to load (or worse,
silently not get picked up) next to a 32-bit `.exe`.

## Toolchain

- Visual Studio install: `C:\Program Files\Microsoft Visual Studio\18\Community`
- x86 dev environment script (sets up `cl.exe`/`link.exe` for 32-bit targets):
  ```
  C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars32.bat
  ```
  Note: this is **`vcvars32.bat`**, not `vcvars64.bat` or `vcvarsall.bat x64` —
  using the wrong one produces a 64-bit DLL that won't load in the game process.

`build.bat` calls `vcvars32.bat` itself, so you don't need to open a special
"x86 Native Tools" command prompt manually — just run the batch file.

## Building the DLL

From the repo root:

```
build.bat
```

This compiles every `.cpp` under `src\` (`dllmain`, `proxy`, `log`,
`config`, `md5`, `identity`, `tables`, `mapping`, `patch_engine`,
`hacks_hfa`, `hacks_hfss`, `input_pump`, `mod`) with
`cl /LD /EHsc /O2 /std:c++17`, links against `dinput8.def` (which exports
`DirectInput8Create` and forwards the other DirectInput8 exports to the real
system DLL) plus `xinput.lib user32.lib advapi32.lib`, and produces
`dinput8.dll` in the repo root.

Expected result: exit code `0` and a `dinput8.dll` file next to `build.bat`.

### Running the build from Claude Code / non-interactive shells

Claude's bash tool cannot invoke a Windows `.bat` file directly. Use a Python
subprocess with `shell=True` and the **full absolute path** (the `.bat` uses
`%~dp0` internally so it works from any starting directory once invoked this
way):

```
python -c "import subprocess; r=subprocess.run(r'\"C:\Users\jamsb\Desktop\Software Projects\Heavy Fire - VRLF Mod\build.bat\"', shell=True); print('EXIT', r.returncode)"
```

A bare `['build.bat']` (no shell, no full path) fails because the working
directory isn't inherited the way `.bat` scripts expect.

## Building and running unit tests

```
build_tests.bat
```

Same x86 toolchain (`vcvars32.bat`). It compiles `tests\test_config.cpp`,
`tests\test_md5.cpp`, `tests\test_identity.cpp`, `tests\test_patch_engine.cpp`,
`tests\test_databank.cpp`, and `tests\test_mapping.cpp` — each paired with
the `src\*.cpp` it exercises (config parsing, MD5 verification, build
identity/MD5-gate selection, patch-engine offset math, databank layout,
pad-to-game-float mapping) — into `tests\run_tests.exe` and runs it,
failing the build on any non-zero exit code from either the compile or the
test run. 14 assertions currently pass across those six files.

`log.cpp` is intentionally **not** part of the test build — it's thin
Win32 file I/O glue (`CRITICAL_SECTION` + `_wfopen_s`) with no pure logic
worth unit testing in isolation, and `hacks_hfa.cpp` / `hacks_hfss.cpp` /
`mod.cpp` are exercised only by manual in-game validation (see `README.md`
→ Deferred manual validation) since they patch live game memory and can't
run meaningfully outside the target process.

## Output layout

- `dinput8.dll` — the proxy DLL. Drop this into the game's install folder
  next to the game `.exe` (e.g.
  `H:\SteamLibrary\steamapps\common\HeavyFireAfghanistan\`) to load it in
  place of the system DirectInput8.
- `heavyfire_vrlf.log` — written next to wherever `dinput8.dll` actually
  loaded from, once the game is launched with the proxy installed.
- Build artifacts (`*.obj`, `*.exp`, `*.lib`, `*.pdb`, `*.ilk`) are left in
  the repo root by `cl`/`link` and are gitignored.
