# HOTD1 Remake VRLF Mod

A BepInEx (Mono, x64) plugin for **THE HOUSE OF THE DEAD Remake** (Steam appid 1694600) that
turns it into a proper lightgun game: true absolute 1:1 crosshair aim for one or two players,
with no DemulShooter and no Arcade Mod. Part of the VR Lightgun Framework (VRLF) family of
companion mods (HOTD2, Heavy Fire, Big Buck Hunter Ultimate).

## What it does

- **Absolute 1:1 aim, solo + 2P co-op.** Each player's crosshair is driven every frame from
  the VRLF **aim bus** (a shared-memory channel, `Local\VRLF_AimBus`, that the framework
  publishes each gun's exact aim UV to). P1 = bus lane 0, P2 = lane 1.
- **Device lock.** Foreign joysticks (e.g. PSVR2 Sense controllers surfacing as HID devices
  under SteamVR) are rejected; only the framework's virtual ViGEmBus pads reach the game.
  The first pad is pinned to Player 1; Player 2 joins through the game's own native join flow.
- **Native fire.** Trigger/reload/start are real pad buttons the game reads itself via
  Rewired — no input synthesis for buttons.
- **Vanilla fallback.** If the framework isn't running (or a gun isn't grabbed), that player's
  aim silently reverts to stock behaviour. Launching the game flat works normally.

## Why the game needs a mod at all

Two hard blockers in the base game, both confirmed by IL and hardware testing:

1. **The cursor is locked in gameplay** (`Cursor.lockState = Locked`), pinning both
   `Input.mousePosition` and the Win32 cursor to screen centre — OS-cursor absolute aim
   (VRLF's standard mechanism, and Sinden-style mouse guns) is architecturally impossible.
2. **The aim chain is deadzone-gated.** `HD_InputManager.handleAiming` contains a literal
   `if (aimInput == Vector2.zero) return;` and its input is Rewired's radially-deadzoned
   stick read — so stick-based absolute aim (pad left stick = aim position) goes dead in a
   ~25%-of-screen disc around centre: the game simply stops calling its own aim code.

The mod therefore drives `HD_Player.SetAim` from the plugin's own `LateUpdate` —
unconditional, every frame, sourced from the aim bus — and suppresses the game's vanilla
crosshair writes (`MovePositionRaw`, `ResetToCenter`) for players it is actively driving.

## Requirements

- **BepInEx 5** (x64, Mono) installed into the game root (`winhttp.dll`,
  `doorstop_config.ini`, `BepInEx/core/`).
- **VR Lightgun Framework** with aim-bus support (AimPublisher), running with a profile whose
  guns set `"pad": true, "pad_aim": true` (see `framework/profiles/` for the shipped
  2-gun profile — P1 red, P2 blue; gun→player wiring is positional).

## Config (`BepInEx/plugins/HotdRemakeVrlf.cfg`)

| Key | Default | Meaning |
|---|---|---|
| `EnableDeviceLock` | `true` | Reject foreign joysticks; pin framework pad 1 to Player 1 |
| `EnableAbsoluteAim` | `true` | Drive crosshairs from the aim bus |
| `EnableCoop` | `true` | Also drive Player 2 from bus lane 1 once they join |
| `HideCrosshair` | `true` | Hide driven players' in-game crosshair (aim by VR gun/laser; also hides the ammo ring) |
| `InvertY` | `true` | Flip bus V to the game's Y-up space |
| `AimScaleX/Y` | `1.0` | Gain about centre; 1.0 = 1:1 edges |
| `AimOffsetX/Y` | `0` | Centre shift (0.5 = one screen half-extent) |
| `AllowedPadNameContains` | `XInput Gamepad` | Device-lock discriminator substring |
| `LogAim` | `false` | Per-frame aim diagnostics in `LogOutput.log` |

The cfg hot-reloads ~1/sec while the game runs, so calibration can be tuned live.

## Physical lightguns (no VR)

The aim bus is VRLF-specific, but the deadzone-gate fix benefits any absolute-aim source. A
planned `AimSource=pad` mode would read an XInput pad's left stick directly (clean — the
deadzone lives in the game's Rewired read, not the API), enabling Sinden-style
"joystick aiming" guns without the framework. Not yet implemented.

## Layout

- `src/Plugin.cs` — plugin entry (GUID `com.vrlf.hotd1remake`); hosts the `LateUpdate` drive
  and cfg hot-reload.
- `src/AbsoluteAim.cs` — per-player drive + vanilla-aim suppressors.
- `src/AimBusReader.cs` — `Local\VRLF_AimBus` shared-memory reader.
- `src/DeviceLock.cs` — foreign-controller rejection + Player 1 pad pinning.
- `src/Diagnostics.cs` — crosshair visibility forcing + optional (`LogAim`) aim logging.
- `src/Config.cs` — cfg load/save.
- `framework/profiles/` — the VRLF profile shipped with this mod.
- `tools/` — recon/diagnostic helpers (`DumpIL.cs`, `bus_watch.py`); not shipped.
- `build.ps1` — compiles `src/*.cs` with `csc.exe` against the game's Managed assemblies +
  BepInEx/Harmony, then deploys into the game's `BepInEx/plugins/`. See `BUILD.md`.

## Version history

- **v1.0.0** — Absolute 1:1 aim (solo + 2P co-op) via the VRLF aim bus, LateUpdate drive,
  deadzone-gate root cause fixed, device lock, native pad fire, vanilla fallback. Validated
  on hardware (PSVR2, solo + co-op).
