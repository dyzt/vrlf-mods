# House of the Dead: Remake VRLF Mod v1.1.0

Makes THE HOUSE OF THE DEAD: Remake a VR lightgun game with the VR Lightgun Framework (VRLF): 1:1 aim for one or two players, and menus you point at and shoot.

## Install

1. Close the game.
2. Extract this zip into the game folder, next to `The House of the Dead Remake.exe`.
3. In VRLF, pick the House of the Dead: Remake profile.

The VRLF mod manager (`vrlf-mods.exe`) does steps 1 and 2 for you.

## Settings

`BepInEx/plugins/HotdRemakeVrlf.cfg`, reloaded while the game runs:

- `HideCrosshair`: hide the in-game crosshair (default true)
- `MenuPointer`: Player 1's gun selects the menu item it points at, so the trigger presses it (default true)
- `MenuCursor`: menus show the cursor whatever device Player 1 is on, so the empty-hand laser clicks (default true)
- `EnableCoop`: Player 2 joins with the second gun (default true)
- `EnableDeviceLock`: only VRLF's virtual pads reach the game (default true)
- `InvertY`, `AimScaleX/Y`, `AimOffsetX/Y`: aim calibration

## Uninstall

Delete `winhttp.dll`, `doorstop_config.ini`, `.doorstop_version` and the `BepInEx` folder from the game folder.
