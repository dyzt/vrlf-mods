# Reload VRLF Mod

A game-folder `dinput8.dll` proxy for **Reload** (Steam app 330370) that hides
the in-game crosshair and (optionally) the first-person weapon/arm model, and can
drive **absolute VR aim** directly from the VR Lightgun Framework — so the game
reads cleanly as a VR lightgun title. No DemulShooter, no external tool.

## How it works

Windows loads this `dinput8.dll` from the game folder before the system one; it
forwards all DirectInput8 calls to the real DLL (input is untouched) and runs one
background thread.

**Crosshair & weapon hiding** — the worker calls the game's **own exported
functions** (`ActorHud::HideModule("crosshair*")` and
`wsInventory::SetRenderWeapon(false)`) every frame. This path **never writes into
game memory** and keeps no offsets — if a future update renames a function, the
mod logs it and no-ops, and the game runs completely stock.

**Absolute VR aim** (optional, `AbsoluteAim`) — the mod reads the framework's
shared-memory aim bus and drives the game's own screen-aim system so the crosshair
tracks your VR gun 1:1, instead of relying on lossy mouse injection. It installs a
small inline hook (via the open-source [MinHook](https://github.com/TsudaKageyu/minhook)
library) on the game's aim update and overrides only the aim *input* the game
reads — it does not reverse struct layouts or patch game data. Requires the
framework running with the Reload profile in `bus` aim mode; without it (or with
`AbsoluteAim=false`) the game keeps its normal mouse aim.

## Install

1. Build `dinput8.dll` (see `BUILD.md`) or take a release build.
2. Copy `dinput8.dll` and `reload_vrlf.cfg` into the Reload install folder, next
   to `reload.exe` (e.g. `...\steamapps\common\Reload\`).
3. Add `-windowed` to Reload's Steam launch options (Properties → Launch
   Options), or to the VR Lightgun Framework shortcut's args. This makes the game
   run in a window the framework can capture; it is required for capture and is
   independent of this mod.
4. Launch normally. `reload_vrlf.log` is written next to the DLL.

## Uninstall

Delete `dinput8.dll` (and `reload_vrlf.cfg` / `reload_vrlf.log`) from the game
folder. The game reverts to stock, no trace left.

## Configuration (`reload_vrlf.cfg`)

`Key=Value` per line; `#` comments and unknown lines ignored; missing keys use
the default.

| Key | Default | Meaning |
|---|---|---|
| `RemoveCrosshair` | `true` | Hide the in-game reticle (all crosshair modules). VR/mouse aim is unaffected. |
| `HideWeapon` | `true` | Hide the first-person weapon/arm model. Set `false` to keep it on screen. |
| `AbsoluteAim` | `true` | Drive aim from the framework's aim bus (needs the framework in `bus` aim mode). `false` = the game's normal mouse aim. |
| `AimGain` | `0.4` | Responsiveness toward the target (P-controller gain). Higher = snappier but can jitter; lower = smoother, laggier. |
| `AimScaleX` / `AimScaleY` | `1.0` | Calibration gain about screen centre per axis. Raise to push the mapped edges out, lower to pull them in. |
| `AimOffsetX` / `AimOffsetY` | `0.0` | Centre offset per axis, if aim sits off to one side. |
| `InvertX` / `InvertY` | `false` | Flip an axis if aim comes out mirrored (Reload needs neither). |
| `VerboseLog` | `false` | Per-loop diagnostics; lifecycle/error lines log regardless. |

## Antivirus

The crosshair/weapon path only calls the game's own exported functions and does
**not** scan or patch game data structures. Absolute aim adds a single inline hook
(via the widely-used, open-source MinHook) on one aim function and overrides its
input — no offset reversing, no data patching. The mod is open source (`src/`) and
vendored MinHook lives in `third_party/minhook/`. If your AV flags the proxy DLL,
add an exclusion for the game folder, or set `AbsoluteAim=false` to disable the
hook (crosshair/weapon hiding then uses exported calls only).
