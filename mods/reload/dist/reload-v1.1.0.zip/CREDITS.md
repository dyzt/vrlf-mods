# Credits

- **VR Lightgun Framework** — the VR intermediary this mod supports.
- Built on the standalone `dinput8.dll` proxy pattern proven by the Heavy Fire
  VRLF mod (which patches memory; this mod instead calls exported functions).
- Crosshair-removal precedent: the lightgun community's use of DemulShooter's
  `-nocrosshair` for Reload (documented on the Sinden wiki). This mod achieves
  the same result without an external process, via the game's own exported
  `ActorHud::HideModule` / `Actor::HideWeapon` API (CloakNT engine).
- **MinHook** by Tsuda Kageyu and contributors (https://github.com/TsudaKageyu/minhook),
  BSD 2-Clause licensed — vendored under `third_party/minhook/` and used for the
  inline hook on `csPlayerCameraScreenAim::Update` that drives absolute VR aim.
  See `third_party/minhook/LICENSE.txt` for its full license text.
