# House of the Dead 2: Remake VRLF Mod (HOD2 Input Lock) v1.1

Makes THE HOUSE OF THE DEAD 2: Remake a VR lightgun game with the VR Lightgun Framework (VRLF): 1:1 aim for one or two players, Player 1 on mouse and keyboard and Player 2 on VRLF's virtual pad, with the PSVR2 Sense controllers kept out of the game.

## Install

1. Close the game.
2. Extract this zip into the game folder, next to `THE HOUSE OF THE DEAD 2 Remake.exe`.
3. In VRLF, pick the House of the Dead 2: Remake profile (version 1 or later).

The VRLF mod manager (`vrlf-mods.exe`) does steps 1 and 2 for you. Co-op needs ViGEmBus for Player 2.

## Settings

`BepInEx/config/com.vrlightgun.hod2inputlock.cfg`:

- `ShowCrosshairs`: show the in-game crosshairs (default false)
- `AbsoluteAim`, `PadAbsoluteAim`: 1:1 aim for Player 1 and Player 2 (default true)
- `PadAimFromBus`: Player 2 aims from the VRLF aim bus, so its pad stick stays centred and never moves menus (default true)
- `ConfineCursor`: keep the cursor in the window during play (default true)
- `InvertY`, `PadInvertY`, `AimScale`, `PadAimScale`: aim calibration
- `Player2GamepadName`: the name VRLF's virtual pad matches (default `XInput`)

## Uninstall

Delete `winhttp.dll`, `doorstop_config.ini`, `.doorstop_version` and the `BepInEx` folder from the game folder.

See `CREDITS.md` for credits.
