# HOD2 Input Lock — VR Lightgun Framework companion mod

A tiny BepInEx plugin for **THE HOUSE OF THE DEAD 2: Remake** (Steam, MegaPixel Studio)
that stops the game handing Player 1 to a gamepad.

## The problem it solves

HOD2:R assigns a player's input device based on device activity. While SteamVR is
running, the **PSVR2 Sense controllers enumerate as a live HID gamepad**, so the game
constantly re-assigns Player 1 to that "gamepad" and then ignores mouse/keyboard —
which makes it undriveable by the VR Lightgun Framework's injected mouse aim.

What the plugin delivers:

- **Player 1 stays keyboard/mouse** (the framework's injected lightgun) — always; a
  foreign gamepad (the PSVR2 HID) can never take a player slot.
- **True 1:1 lightgun aim for both players.** HOD2:R has no native absolute mouse aim
  (it reads deltas → velocity feel). The plugin drives each player's crosshair from an
  *absolute* source instead: Player 1 from the OS cursor, Player 2 from its virtual-pad
  left stick (which the framework feeds with the absolute aim position).
- **The PSVR2 Sense controllers stop interfering.** Their connect/disconnect flicker and
  stick/gyro drift previously churned the game's input system (unresponsive menus) and
  spammed the multiplayer controller-assignment picker as phantom "players 3/4." They are
  now ignored at the device-change level and stripped from the game's controller registry.
- **Clean co-op assignment.** The multiplayer assignment popup ignores foreign gamepads
  and doesn't re-appear once both players are assigned.

Works solo (just the P1 lock + absolute aim) and co-op (P1 = mouse lightgun, P2 = virtual
pad) — the discriminator is simply whether the framework's virtual pad is present.

## How it works

All via Harmony patches on the game's own methods (in-memory; no game files changed):

- **Device assignment** — `MP_ControllerManager.AssignController(PlayerType, MP_InputController, bool)`
  is the single funnel for every controller→player assignment. A prefix vetoes any gamepad
  → P1 and any *foreign* gamepad → any player; mouse/keyboard is pinned to P1; the P2 pad
  (matched by `Player2GamepadName`) is allowed to P2.
- **Absolute aim** — a postfix on `CR_Player.Update` sets each player's crosshair via
  `CR_Crosshair.SetPosition(normalized)` from the absolute source (OS cursor for P1, pad
  left stick for P2), overriding the native relative/velocity aim.
- **PSVR2 flicker** — a prefix on `MP_ControllerManager.onDeviceChange` skips foreign
  gamepad device-changes entirely (no input-cache churn); a postfix on `initControllers`
  strips foreign gamepads from the `AllControllers`/`Gamepads` registry.
- **Assignment popup** — the multiplayer-assignment popup's `checkInput` /
  `onControllerConnected` / `onControllerDisconnected` ignore foreign gamepads, and
  `ShowMultiplayerAssignment` is suppressed once both players are already assigned.

Reverse-engineered against the game's `Assembly-CSharp.dll` (Unity Mono), with the
"Mystery Wizard" mod as the initial map. See `src/Plugin.cs` — it's one file, heavily
commented, ~350 lines.

## Install

1. Close the game.
2. Copy the **contents** of this folder (`winhttp.dll`, `doorstop_config.ini`,
   `.doorstop_version`, and the `BepInEx` folder) into the game's install folder,
   next to `THE HOUSE OF THE DEAD 2 Remake.exe`:
   `...\steamapps\common\THE HOUSE OF THE DEAD 2 Remake\`
3. Launch the game once. BepInEx generates `BepInEx\LogOutput.log`.

## First-run tuning (important)

The plugin identifies the framework's Player-2 pad by a **name substring**, configured in
`BepInEx\config\com.vrlightgun.hod2inputlock.cfg` (created on first run):

```
[General]
## Substring matched (case-insensitive) against a gamepad's Name to identify the
## framework's virtual pad = Player 2. Any gamepad whose Name does NOT contain this
## (e.g. the PSVR2 HID) is blocked from being assigned to any player. Leave blank to
## force solo: all gamepads blocked, Player 1 = mouse/keyboard only.
Player2GamepadName = XInput

## Log every controller-assignment attempt and every device add/remove.
VerboseLog = true
```

With `VerboseLog = true`, the log prints the exact Name of every device, e.g.:

```
HOD2InputLock DeviceChange: Added name='XInputControllerWindows' display='Xbox Controller'
AssignController req: player=Player1 ctrl='...' gamepad=True ...
HOD2InputLock BLOCK: foreign gamepad '...' -> Player1
```

Read `BepInEx\LogOutput.log`, confirm:
- the framework's ViGEmBus pad shows up (default match `XInput` should catch it), and
- the PSVR2 shows a *different* Name (so it gets blocked).

If the default `XInput` doesn't match your pad, set `Player2GamepadName` to a substring
of its real Name. For **solo-only** play, set `Player2GamepadName =` (blank) to block
every gamepad.

Once tuned, set `VerboseLog = false` to quiet the log.

## Absolute (lightgun) aim — v0.2

HOD2:R has no native absolute mouse aim — it reads mouse *deltas*, so even injected
absolute cursor movement feels relative/velocity-based. This plugin adds true 1:1
lightgun aim by driving Player 1's crosshair directly from the absolute OS cursor
position each frame (the framework already places that cursor at the true aim point).

Technique adapted from the Mystery Wizard mod (which blocks the game's relative crosshair
path and drives `CR_Crosshair.SetPosition` from its own absolute tracker) — here the
absolute source is simply the OS cursor, so the per-frame absolute set overrides the
relative path with no extra tracking.

Config under `[Aim]` in `com.vrlightgun.hod2inputlock.cfg`:

```
[Aim]
AbsoluteAim   = true    ## 1:1 lightgun aim from the cursor (false = game's native relative aim)
InvertY       = false   ## flip if vertical aim is upside-down
ConfineCursor = true    ## confine+hide the OS cursor during gameplay so absolute position tracks
LogAim        = true    ## throttled log of cursor/crosshair coords (~1 line/sec) for diagnostics
```

With `LogAim = true` the log prints `AbsAim Player1 cursor … norm=(x,y)` lines — if the
values track your aim, absolute aim is working; if frozen near center, the game is
locking the cursor (leave `ConfineCursor = true`, which defeats it). If the crosshair
under/overshoots the screen edges, tune `AimScale`. Set `LogAim = false` once happy.

## Player 2 absolute aim (co-op) — v0.3

Player 2 plays through a framework **virtual ViGEmBus pad**. Natively the game would give
that pad velocity/stick aiming, but the framework drives the pad's **left stick with the
absolute aim UV** (`pad_aim` guns). So the plugin reads P2's assigned pad left stick and
feeds it straight into the same `SetPosition` absolute setter — the DemulShooter-style
"map the axis to absolute coordinates" trick, done in-process. Both players get 1:1
lightgun aim.

`[Aim]` config for P2:

```
PadAbsoluteAim = true    ## P2 absolute aim from the pad left stick (false = native velocity)
PadAimScale    = 1.0     ## scale the pad stick -> crosshair; tune like AimScale
```

Requirements for co-op: the framework profile must give Player 2 a `pad: true,
pad_aim: true` gun (any model). The `AbsAim Player2 pad norm=(x,y)` log lines show the
stick values for tuning `PadAimScale`. P2's **fire/reload buttons** still go through the
game's native gamepad handling, so the profile's P2 `pad_button` bindings must match
HOD2's gamepad scheme (may need tuning — see the framework co-op profile).

## Requirements

- The VR Lightgun Framework running the game with mouse aim injection (Player 1).
- For co-op Player 2: the framework's virtual ViGEmBus pad (ViGEmBus installed).

## Uninstall

Delete `winhttp.dll`, `doorstop_config.ini`, `.doorstop_version`, and the `BepInEx`
folder from the game directory.

## Rebuild

Source is in `src/Plugin.cs`. See `src/BUILD.md` for the compile command.

## Status

**v0.8 — solo and co-op both validated in-VR.** Both players get true 1:1 lightgun aim,
the multiplayer assignment is clean, and the PSVR2 Sense no longer interfere anywhere.

Changelog:

- **v0.1 — device-assignment lock: validated in-VR.** P1 stays mouse/keyboard, PSVR2 blocked.
- **v0.2 — P1 absolute (lightgun) aim: validated in-VR.** 1:1 aim from the cursor.
- **v0.3 — P2 absolute aim (co-op) from the pad left stick: validated in-VR.** Co-op profile
  needs a `pad_aim: true` Player-2 gun; tune with `PadAimScale`. P2 fire/reload go through the
  game's native gamepad handling (fire = pad A, reload = pad B for HOD2).
- **v0.4 — disable foreign gamepads.** (Superseded by v0.6.) Disabled the PSVR2 Sense HIDs in
  the game's InputSystem; also blocked mouse/keyboard from Player 2 (keeps M&KB on P1).
- **v0.5 — `PadInvertY`.** Separate vertical-flip for Player 2's pad aim (default true) so it
  can't affect P1's cursor aim.
- **v0.6 — cooperative picker fix (replaces v0.4's device-disable).** Disabling the Sense
  fought the game and made them flicker in the assignment picker. Instead, the multiplayer
  controller-assignment popup now simply *ignores* foreign gamepads: it won't read their
  drift (`checkInput`) or churn on their connect/disconnect flicker
  (`onControllerConnected`/`Disconnected`). The Sense go inert in the picker so mouse+keyboard
  → P1 and the virtual pad → P2 assign cleanly. The mouse/keyboard→P1-only rule stays.
- **v0.7 — swallow the flicker at the source (fixes pad unresponsiveness across ALL menus).**
  The Sense's rapid connect/disconnect flicker was firing `MP_ControllerManager.onDeviceChange`
  constantly — clearing input caches and re-evaluating controllers every time — so the pad's
  input never landed in any menu. The plugin now skips that handler entirely for foreign
  gamepads, so their flicker never disturbs the game's input system. (Non-gamepad devices and
  the P2 pad still process normally.)
- **v0.8 — remove the Sense from the registry + stop the assignment popup reappearing.**
  (Issue 2) After `initControllers`, foreign gamepads are stripped from the game's
  `AllControllers`/`Gamepads` registry, so the Sense no longer appear as slots in the
  assignment popup at all. (Issue 3) `ShowMultiplayerAssignment` is skipped when both players
  already have a controller assigned, so the popup shows once but doesn't re-appear when the
  multiplayer game loads.
- **v0.9 — hide crosshairs toggle.** New `[Visuals] ShowCrosshairs` config; set it `false` to
  make the in-game crosshairs invisible (aim still works). Uses the Mystery Wizard mod's
  technique — disabling the crosshair's child Renderers/Behaviours — re-applied each frame so
  the game can't un-hide it.
- **v0.10 — crosshairs hidden by default + config shipped.** `ShowCrosshairs` now defaults to
  `false`, and a ready-to-edit `BepInEx/config/com.vrlightgun.hod2inputlock.cfg` ships in the
  package (no need to launch once to generate it). Diagnostic logging (`VerboseLog`, `LogAim`)
  is off in the shipped config.

## Hide crosshairs — v0.10

Crosshairs are **hidden by default**. The config ships pre-generated at
`BepInEx/config/com.vrlightgun.hod2inputlock.cfg`; to bring the crosshairs back, set:

```
[Visuals]
ShowCrosshairs = true    ## false (default) = hidden; true = normal
```

The crosshair still exists and tracks your aim (hit detection is unchanged) — when hidden,
only its visuals are disabled.
