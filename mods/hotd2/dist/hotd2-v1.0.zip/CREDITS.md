# Credits & Licenses

## This mod
`HOD2InputLock` (`BepInEx/plugins/HOD2InputLock.dll`) — part of the VR Lightgun
Framework project. Source in `src/`.

## Reverse-engineering credit
The game's input model was first mapped by **"Mystery Wizard - HOD2 Lightgun Fix"**
(`com.ME.HODMysteryFix`), which pointed to the relevant `MP_ControllerManager` methods.
This plugin **shares none of that mod's code** — it is an independent implementation
targeting the same public game methods, with its own (unconditional, assignment-based)
approach. Thanks to Mystery Wizard for the groundwork.

## Bundled redistributables
- **BepInEx 5.4.23** — Unity mod loader. MIT/LGPL. https://github.com/BepInEx/BepInEx
- **Unity Doorstop 4.4.0** (`winhttp.dll`) — bootstrapper bundled with BepInEx.
- **HarmonyX / 0Harmony 2.9** — runtime patching. MIT/LGPL.
- **MonoMod**, **Mono.Cecil** — bundled with BepInEx.

These are redistributed unmodified from the BepInEx release used to build this package.

## Game
THE HOUSE OF THE DEAD 2: Remake © MegaPixel Studio / SEGA. This mod is an unofficial
fan tool; it modifies only in-memory runtime behavior (via Harmony) and does not alter
any game files.
