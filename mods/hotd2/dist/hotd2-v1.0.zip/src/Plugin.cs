using System;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using MegaPixel.Input;

// HOD2 Input Lock — pins THE HOUSE OF THE DEAD 2: Remake controller assignment so
// a foreign gamepad (the PSVR2 Sense HID, seen by the game while SteamVR runs) can
// never take a player slot. Player 1 stays keyboard/mouse (the framework's injected
// lightgun); an optional framework virtual pad may take Player 2.
//
// Reverse-engineering of the game's input model credit: "Mystery Wizard - HOD2
// Lightgun Fix" (com.ME.HODMysteryFix). This plugin shares none of its code; it
// targets the same game methods with an independent, unconditional implementation.
namespace HOD2InputLock
{
    [BepInPlugin("com.vrlightgun.hod2inputlock", "HOD2 Input Lock", "1.0.0")]
    public class Plugin : BaseUnityPlugin
    {
        internal static ManualLogSource Log;
        internal static ConfigEntry<string> Player2GamepadName;
        internal static ConfigEntry<bool> VerboseLog;
        internal static ConfigEntry<bool> AbsoluteAim;
        internal static ConfigEntry<bool> InvertY;
        internal static ConfigEntry<bool> ConfineCursor;
        internal static ConfigEntry<bool> LogAim;
        internal static ConfigEntry<float> AimScale;
        internal static ConfigEntry<bool> PadAbsoluteAim;
        internal static ConfigEntry<float> PadAimScale;
        internal static ConfigEntry<bool> PadInvertY;
        internal static ConfigEntry<bool> ShowCrosshairs;

        // Cached reflection handles for game members that may be non-public across assemblies.
        private static readonly MethodInfo _isGamepad =
            AccessTools.Method(typeof(MP_ControllerManager), "isControllerGamepad",
                new Type[] { typeof(MP_InputController) });
        internal static readonly MethodInfo _isMouseKb =
            AccessTools.Method(typeof(MP_ControllerManager), "IsPlayerUsingMouseOrKeyboard",
                new Type[] { typeof(PlayerType) });
        internal static readonly FieldInfo _playerType =
            AccessTools.Field(typeof(CR_Player), "Type");
        internal static readonly FieldInfo _ctrlDevice =
            AccessTools.Field(typeof(MP_InputController), "Device");
        internal static readonly FieldInfo _allControllers =
            AccessTools.Field(typeof(MP_ControllerManager), "AllControllers");
        internal static readonly FieldInfo _gamepads =
            AccessTools.Field(typeof(MP_ControllerManager), "Gamepads");

        private void Awake()
        {
            Log = Logger;
            Player2GamepadName = Config.Bind("General", "Player2GamepadName", "XInput",
                "Substring matched (case-insensitive) against a gamepad's Name to identify the framework's virtual pad = Player 2. " +
                "Any gamepad whose Name does NOT contain this (e.g. the PSVR2 HID) is blocked from being assigned to any player. " +
                "Leave blank to force solo: all gamepads blocked, Player 1 = mouse/keyboard only.");
            VerboseLog = Config.Bind("General", "VerboseLog", true,
                "Log every controller-assignment attempt and every device add/remove (use this once to discover the exact device Names).");

            AbsoluteAim = Config.Bind("Aim", "AbsoluteAim", true,
                "Drive Player 1's crosshair from the absolute mouse cursor position (true lightgun aim) instead of the game's native relative/velocity mouse aim.");
            InvertY = Config.Bind("Aim", "InvertY", false,
                "Flip the vertical axis if absolute aim comes out upside-down.");
            ConfineCursor = Config.Bind("Aim", "ConfineCursor", true,
                "During gameplay, confine + hide the OS cursor so the injected absolute position always tracks (defeats any cursor-lock the game applies). Disable if it interferes.");
            LogAim = Config.Bind("Aim", "LogAim", true,
                "Throttled logging of the read cursor position / computed crosshair coords (once per ~60 frames) for diagnosing absolute aim.");
            AimScale = Config.Bind("Aim", "AimScale", 1.0f,
                "Player 1 (cursor) scale: multiply the normalized aim so the crosshair reaches the screen edges exactly. Raise if it undershoots the edges, lower if it overshoots.");
            PadAbsoluteAim = Config.Bind("Aim", "PadAbsoluteAim", true,
                "Give Player 2 (virtual pad) the same absolute lightgun aim, sourced from the pad's LEFT stick (the framework drives it with the absolute aim UV) instead of the game's native velocity stick aim.");
            PadAimScale = Config.Bind("Aim", "PadAimScale", 1.0f,
                "Player 2 (pad) scale: multiply the pad left-stick value before mapping to the crosshair. Tune like AimScale.");
            PadInvertY = Config.Bind("Aim", "PadInvertY", true,
                "Flip Player 2's vertical axis (the virtual pad's stick Y is inverted relative to the screen). Separate from P1's InvertY so it can't affect the cursor player.");
            ShowCrosshairs = Config.Bind("Visuals", "ShowCrosshairs", false,
                "Show the in-game crosshairs. Default false = hidden (aim still works; the crosshair is just made invisible). Set true to bring them back.");

            try
            {
                var h = new Harmony("com.vrlightgun.hod2inputlock");
                h.PatchAll(Assembly.GetExecutingAssembly());
                Log.LogInfo("HOD2 Input Lock active. Player2GamepadName='" + Player2GamepadName.Value +
                    "', VerboseLog=" + VerboseLog.Value);
            }
            catch (Exception e)
            {
                Log.LogError("HOD2 Input Lock: Harmony PatchAll failed: " + e);
            }
        }

        internal static bool IsGamepad(MP_InputController c)
        {
            if (c == null || _isGamepad == null) return false;
            try { return (bool)_isGamepad.Invoke(null, new object[] { c }); }
            catch (Exception e) { Log.LogError("isControllerGamepad reflection failed: " + e); return false; }
        }

        internal static string SafeName(MP_InputController c)
        {
            try { return c == null ? null : c.Name; }
            catch { return null; }
        }

        // Is this gamepad the framework's virtual pad (the only gamepad allowed, and only for Player 2)?
        internal static bool IsPlayer2Pad(MP_InputController c)
        {
            string match = Player2GamepadName.Value;
            if (string.IsNullOrEmpty(match)) return false;
            string name = SafeName(c);
            return name != null && name.IndexOf(match, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        internal static bool IsMouseKb(PlayerType pt)
        {
            if (_isMouseKb == null) return false;
            try { return (bool)_isMouseKb.Invoke(null, new object[] { pt }); }
            catch { return false; }
        }

        // A connected gamepad that is NOT the framework's Player-2 pad — i.e. a PSVR2 Sense
        // HID. These must not participate in the game's controller-assignment UI (their
        // drift/flicker otherwise thrashes the picker and fights the real pad for control).
        internal static bool IsForeignGamepad(MP_InputController c)
        {
            return IsGamepad(c) && !IsPlayer2Pad(c);
        }

        // Same test at the raw InputSystem-device level (used to swallow the Sense's flicker
        // before the game reacts to it).
        internal static bool IsForeignGamepadDevice(UnityEngine.InputSystem.InputDevice d)
        {
            if (!(d is UnityEngine.InputSystem.Gamepad)) return false;
            string match = Player2GamepadName.Value;
            if (string.IsNullOrEmpty(match)) return true; // solo: every gamepad is foreign
            try
            {
                if (d.name != null && d.name.IndexOf(match, StringComparison.OrdinalIgnoreCase) >= 0) return false;
                if (d.displayName != null && d.displayName.IndexOf(match, StringComparison.OrdinalIgnoreCase) >= 0) return false;
            }
            catch { }
            return true;
        }
    }

    // THE chokepoint: every controller->player assignment funnels through this method
    // (it is the only writer of PlayerAssignedControllers[player]). Vetoing here stops
    // the PSVR2 takeover at its source, whatever triggers it (device-change, activity,
    // popups, TryToAssignAnyFreeControllerToPlayer, ...).
    [HarmonyPatch(typeof(MP_ControllerManager), "AssignController",
        new Type[] { typeof(PlayerType), typeof(MP_InputController), typeof(bool) })]
    internal static class AssignController_Patch
    {
        private static bool Prefix(PlayerType _player, MP_InputController _controller, bool _force)
        {
            try
            {
                if (_controller == null) return true; // unassignment path — let it run

                bool isGamepad = Plugin.IsGamepad(_controller);
                string name = Plugin.SafeName(_controller);
                if (Plugin.VerboseLog.Value)
                    Plugin.Log.LogInfo("AssignController req: player=" + _player + " ctrl='" + name +
                        "' gamepad=" + isGamepad + " force=" + _force);

                if (!isGamepad)
                {
                    // Keep mouse+keyboard together on Player 1; never let the keyboard/mouse
                    // land on Player 2 (the game did this when no pad was present).
                    if (_player != PlayerType.Player1)
                    {
                        Plugin.Log.LogInfo("HOD2InputLock BLOCK: keyboard/mouse '" + name + "' -> " + _player +
                            " (mouse/keyboard is Player 1 only)");
                        return false;
                    }
                    return true;
                }

                if (Plugin.IsPlayer2Pad(_controller))
                {
                    if (_player == PlayerType.Player2) return true; // our virtual pad -> Player 2 OK
                    Plugin.Log.LogInfo("HOD2InputLock BLOCK: virtual pad '" + name + "' -> " + _player +
                        " (pad is Player 2 only)");
                    return false;
                }

                // Any other gamepad (the PSVR2 HID) must never hold a player slot.
                Plugin.Log.LogInfo("HOD2InputLock BLOCK: foreign gamepad '" + name + "' -> " + _player);
                return false;
            }
            catch (Exception e)
            {
                Plugin.Log.LogError("AssignController prefix error (failing open): " + e);
                return true; // never break the game on our account
            }
        }
    }

    // Suppress the on-screen "assign controller" popup for foreign gamepads so plugging in
    // the PSVR2 doesn't throw up a modal we can't dismiss.
    [HarmonyPatch(typeof(MP_ControllerManager), "InvokeAssignControllerPopup")]
    internal static class AssignPopup_Patch
    {
        private static bool Prefix(MP_InputController _controller)
        {
            try
            {
                if (Plugin.IsGamepad(_controller) && !Plugin.IsPlayer2Pad(_controller))
                {
                    if (Plugin.VerboseLog.Value)
                        Plugin.Log.LogInfo("HOD2InputLock: suppressing assign popup for foreign gamepad '" +
                            Plugin.SafeName(_controller) + "'");
                    return false;
                }
            }
            catch (Exception e) { Plugin.Log.LogError("InvokeAssignControllerPopup prefix error: " + e); }
            return true;
        }
    }

    // Swallow the PSVR2 Sense flicker at the source: skip the game's device-change handler
    // entirely for foreign gamepads, so their rapid connect/disconnect never clears input
    // caches, re-evaluates controllers, or fires connect/disconnect events. This is what
    // keeps the pad responsive across ALL menus (the flicker was churning the whole input
    // system, not just the assignment picker). Non-gamepad + the P2 pad still process
    // normally. Also logs every device change for diagnostics.
    [HarmonyPatch(typeof(MP_ControllerManager), "onDeviceChange")]
    internal static class DeviceChange_Patch
    {
        private static bool Prefix(UnityEngine.InputSystem.InputDevice _device,
                                   UnityEngine.InputSystem.InputDeviceChange _change)
        {
            try
            {
                if (Plugin.IsForeignGamepadDevice(_device))
                {
                    if (Plugin.VerboseLog.Value)
                        Plugin.Log.LogInfo("HOD2InputLock: ignoring device-change " + _change + " for foreign gamepad '" +
                            _device.displayName + "' (blocks flicker churn)");
                    return false; // skip the game's handler — no churn from the Sense flicker
                }
                if (Plugin.VerboseLog.Value && _device != null)
                    Plugin.Log.LogInfo("HOD2InputLock DeviceChange: " + _change + " name='" + _device.name +
                        "' display='" + _device.displayName + "'");
            }
            catch (Exception e) { Plugin.Log.LogError("onDeviceChange prefix error: " + e); }
            return true;
        }
    }

    // Issue 2: after the game builds its controller registry (AllControllers / Gamepads) from
    // InputSystem.devices, strip out foreign gamepads (the PSVR2 Sense) so they never appear in
    // the assignment popup, never count toward assignment, and can't be assigned. Combined with
    // the onDeviceChange skip (hotplug), the Sense are simply absent from the game's controllers.
    [HarmonyPatch(typeof(MP_ControllerManager), "initControllers")]
    internal static class InitControllers_Patch
    {
        private static void Postfix()
        {
            try
            {
                var gamepads = Plugin._gamepads != null
                    ? Plugin._gamepads.GetValue(null) as System.Collections.Generic.List<MP_InputController>
                    : null;
                if (gamepads != null)
                {
                    int removed = gamepads.RemoveAll(delegate (MP_InputController c) { return Plugin.IsForeignGamepad(c); });
                    if (removed > 0 && Plugin.VerboseLog.Value)
                        Plugin.Log.LogInfo("HOD2InputLock: removed " + removed + " foreign gamepad(s) from Gamepads registry");
                }

                var all = Plugin._allControllers != null
                    ? Plugin._allControllers.GetValue(null) as System.Collections.Generic.Dictionary<int, MP_InputController>
                    : null;
                if (all != null)
                {
                    var drop = new System.Collections.Generic.List<int>();
                    foreach (var kv in all)
                        if (Plugin.IsForeignGamepad(kv.Value)) drop.Add(kv.Key);
                    foreach (int k in drop) all.Remove(k);
                    if (drop.Count > 0 && Plugin.VerboseLog.Value)
                        Plugin.Log.LogInfo("HOD2InputLock: removed " + drop.Count + " foreign gamepad(s) from AllControllers registry");
                }
            }
            catch (Exception e) { Plugin.Log.LogError("initControllers postfix error: " + e); }
        }
    }

    // Issue 3: the multiplayer controller-assignment popup re-triggers when the game loads,
    // even though controllers are already assigned. Skip ShowMultiplayerAssignment when both
    // players already have a controller, so the first (real) assignment shows but the redundant
    // reload one does not.
    [HarmonyPatch(typeof(MP_ControllerDisconnectedPopup), "ShowMultiplayerAssignment")]
    internal static class ShowMultiplayerAssignment_Patch
    {
        private static bool Prefix(ref bool __result)
        {
            try
            {
                MP_InputController[] pac = MP_ControllerManager.PlayerAssignedControllers;
                if (pac != null && pac.Length >= 2 && pac[0] != null && pac[1] != null)
                {
                    if (Plugin.VerboseLog.Value)
                        Plugin.Log.LogInfo("HOD2InputLock: suppressing redundant multiplayer-assignment popup (both players already assigned)");
                    __result = false;
                    return false; // skip — don't re-show
                }
            }
            catch (Exception e) { Plugin.Log.LogError("ShowMultiplayerAssignment prefix error: " + e); }
            return true;
        }
    }

    // Make the multiplayer controller-assignment popup ignore foreign gamepads (the PSVR2
    // Sense HIDs). Without this, the popup lists them as extra "player 3/4" slots and reads
    // their stick/gyro drift every frame (checkInput -> checkGamepad), thrashing the slots
    // and fighting the real virtual pad for control; their connect/disconnect flicker also
    // churns the list. Skipping these three handlers for foreign gamepads makes the Sense
    // inert in the picker so mouse+keyboard -> P1 and the virtual pad -> P2 assign cleanly.
    [HarmonyPatch(typeof(CR_ControllerDisconnectedPopupVariant_MultiplayerAssignment))]
    internal static class MultiplayerAssignPopup_Patch
    {
        [HarmonyPrefix]
        [HarmonyPatch("checkInput")]
        private static bool CheckInput(MP_InputController _controller)
        {
            // false = skip original (don't read this controller's input into its item)
            return !Plugin.IsForeignGamepad(_controller);
        }

        [HarmonyPrefix]
        [HarmonyPatch("onControllerConnected")]
        private static bool OnConnected(MP_InputController _controller)
        {
            return !Plugin.IsForeignGamepad(_controller);
        }

        [HarmonyPrefix]
        [HarmonyPatch("onControllerDisconnected")]
        private static bool OnDisconnected(MP_InputController _controller)
        {
            return !Plugin.IsForeignGamepad(_controller);
        }
    }

    // Absolute (lightgun) aim: each frame, position a player's crosshair from an ABSOLUTE
    // source instead of the game's native relative (mouse) / velocity (stick) aim. Runs
    // after CR_Player.Update, so it overrides whatever the native path did that frame.
    //
    //   Player 1 (mouse/keyboard): the OS cursor position, which the framework injects at
    //     the true aim point (Mouse.current.position).
    //   Player 2 (virtual pad): the pad's LEFT stick, which the framework drives with the
    //     absolute aim UV via LightgunVirtualPad::set_aim — so the stick value IS the
    //     absolute on-screen position, not a velocity. This is the DemulShooter-style
    //     axis-to-absolute mapping, done in-process.
    //
    // Approach adapted from "Mystery Wizard - HOD2 Lightgun Fix" (it blocks the relative
    // crosshair path and drives CR_Crosshair.SetPosition(normalized) from its own absolute
    // tracker). Here the per-frame absolute SetPosition simply wins over the native path,
    // so no blocking is needed.
    [HarmonyPatch(typeof(CR_Player), "Update")]
    internal static class PlayerAim_Patch
    {
        private static int _logCounter;

        private static void Postfix(CR_Player __instance)
        {
            try
            {
                if (!Plugin.AbsoluteAim.Value || __instance == null || Plugin._playerType == null) return;

                PlayerType pt = (PlayerType)Plugin._playerType.GetValue(__instance);
                CR_Crosshair ch = __instance.Crosshair;
                if (ch == null) return;

                float nx, ny;
                string src;

                if (Plugin.IsMouseKb(pt))
                {
                    // Player 1 — absolute OS cursor.
                    var mouse = UnityEngine.InputSystem.Mouse.current;
                    if (mouse == null) return;
                    if (Plugin.ConfineCursor.Value)
                    {
                        UnityEngine.Cursor.lockState = UnityEngine.CursorLockMode.Confined;
                        UnityEngine.Cursor.visible = false;
                    }
                    UnityEngine.Vector2 p = mouse.position.ReadValue();
                    float w = UnityEngine.Screen.width, h = UnityEngine.Screen.height;
                    if (w <= 0f || h <= 0f) return;
                    // Screen pixels (origin bottom-left) -> centered normalized [-1,1].
                    nx = ((p.x / w) * 2f - 1f) * Plugin.AimScale.Value;
                    ny = ((p.y / h) * 2f - 1f) * Plugin.AimScale.Value;
                    if (Plugin.InvertY.Value) ny = -ny;
                    src = "cursor";
                }
                else
                {
                    // Player 2 — absolute from the assigned pad's left stick.
                    if (!Plugin.PadAbsoluteAim.Value) return;
                    var gp = GetAssignedGamepad(pt);
                    if (gp == null) return;
                    // Unprocessed = no stick deadzone, so center-screen aim isn't dead.
                    UnityEngine.Vector2 s = gp.leftStick.ReadUnprocessedValue();
                    nx = s.x * Plugin.PadAimScale.Value;
                    ny = s.y * Plugin.PadAimScale.Value;
                    if (Plugin.PadInvertY.Value) ny = -ny;
                    src = "pad";
                }

                nx = UnityEngine.Mathf.Clamp(nx, -1f, 1f);
                ny = UnityEngine.Mathf.Clamp(ny, -1f, 1f);

                ch.SetPosition(new UnityEngine.Vector3(nx, ny, 0f));

                if (!Plugin.ShowCrosshairs.Value) HideCrosshairVisuals(ch);

                if (Plugin.LogAim.Value && (++_logCounter % 60 == 0))
                    Plugin.Log.LogInfo("AbsAim " + pt + " " + src + " norm=(" +
                        nx.ToString("0.00") + "," + ny.ToString("0.00") + ")");
            }
            catch (Exception e) { Plugin.Log.LogError("PlayerAim postfix error: " + e); }
        }

        // Hide a crosshair's visuals (copied from the Mystery Wizard mod's approach): disable
        // every child Renderer and every child Behaviour EXCEPT the CR_Crosshair itself, so the
        // crosshair sprite/Images vanish while its positioning logic (which we drive) stays live.
        // Aim is unaffected — SetPosition still works and hit detection reads the (invisible)
        // crosshair's position. Re-applied each frame here, so a game re-enable can't un-hide it.
        private static void HideCrosshairVisuals(CR_Crosshair ch)
        {
            try
            {
                UnityEngine.Behaviour[] behaviours = ch.GetComponentsInChildren<UnityEngine.Behaviour>();
                for (int i = 0; i < behaviours.Length; i++)
                    if (behaviours[i] != null && !(behaviours[i] is CR_Crosshair) && behaviours[i].enabled)
                        behaviours[i].enabled = false;

                UnityEngine.Renderer[] renderers = ch.GetComponentsInChildren<UnityEngine.Renderer>();
                for (int i = 0; i < renderers.Length; i++)
                    if (renderers[i] != null && renderers[i].enabled)
                        renderers[i].enabled = false;
            }
            catch (Exception e) { Plugin.Log.LogError("HideCrosshairVisuals error: " + e); }
        }

        // The InputSystem Gamepad assigned to this player (its left stick carries the
        // framework's absolute aim UV). Null if the player has no gamepad assigned.
        private static UnityEngine.InputSystem.Gamepad GetAssignedGamepad(PlayerType pt)
        {
            try
            {
                MP_InputController[] pac = MP_ControllerManager.PlayerAssignedControllers;
                int idx = (int)pt;
                if (pac == null || idx < 0 || idx >= pac.Length) return null;
                MP_InputController ctrl = pac[idx];
                if (ctrl == null || Plugin._ctrlDevice == null) return null;
                return Plugin._ctrlDevice.GetValue(ctrl) as UnityEngine.InputSystem.Gamepad;
            }
            catch { return null; }
        }
    }
}
