# Building HOD2InputLock.dll

Single source file (`Plugin.cs`), no SDK required — compiles with the .NET Framework
C# compiler that ships with Windows.

## References
- `BepInEx.dll`, `0Harmony.dll` — from `BepInEx/core/` (in this package)
- `Assembly-CSharp.dll`, `Unity.InputSystem.dll`, `UnityEngine.CoreModule.dll`,
  `UnityEngine.dll` — from the game's `..._Data/Managed/` folder

## Compile (from the folder containing Plugin.cs)

```
CORE="<game>/BepInEx/core"            # or this package's BepInEx/core
MGD="<game>/..._Data/Managed"

"C:/Windows/Microsoft.NET/Framework64/v4.0.30319/csc.exe" \
  -nologo -target:library -out:HOD2InputLock.dll \
  -r:"$MGD/netstandard.dll" \
  -lib:"$CORE" -lib:"$MGD" \
  -r:BepInEx.dll -r:0Harmony.dll \
  -r:Assembly-CSharp.dll -r:Unity.InputSystem.dll \
  -r:UnityEngine.CoreModule.dll -r:UnityEngine.dll \
  Plugin.cs
```

`netstandard.dll` must be referenced **by full path from the game's Managed folder**
(it is version 2.1.0.0; the Framework's own netstandard is 2.0 and causes a
`CS0012 System.Object … netstandard 2.1` error). The remaining `CS1684` ReadOnlySpan
warning is benign. Output `HOD2InputLock.dll` goes in `BepInEx/plugins/`.

## Notes
- Targets BepInEx 5.4.23 (Unity Mono) / HarmonyX 2.9, matching the bundled runtime.
- If the game updates and the plugin fails to load or stops working, the method it
  patches (`MP_ControllerManager.AssignController(PlayerType, MP_InputController, bool)`)
  may have changed — re-verify against the new `Assembly-CSharp.dll` and rebuild.
