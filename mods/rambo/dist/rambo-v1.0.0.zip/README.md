# Rambo VRLF Mod

Makes both players' crosshairs in Rambo: The Video Game follow their VR guns 1:1
in the VR Lightgun Framework.

## Install

1. Extract this zip into the game folder, beside `Rambo.exe`.
2. In VRLF, pick the Rambo: The Video Game profile.
3. In game, Options > Display: set Crosshair to None and turn Show Weapons off.
4. On the Choose Controllers screen, press A on each gun to join.

Settings are in `rambo_vrlf.cfg`. Delete `dinput8.dll` to uninstall.
